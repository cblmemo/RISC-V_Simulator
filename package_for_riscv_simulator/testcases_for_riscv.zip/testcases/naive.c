#include "io.inc"

int main() {
  printInt(177);
  return judgeResult; // 94
}
